package ngu0120.test3;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Builder
@Entity
@Table(name = "Car")
public class Car {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "color")
    private String color;
    @Column(name = "weight")
    private int weight;
    @Column(name = "max_speed")
    private int maxSpeed;
    @Column(name = "rz")
    private String rz;
    @Column(name = "brand")
    private String brand;
    @Column(name = "type")
    private String type;

    private Car() {}

    public String getColor() {
        return color;
    }

    public int getWeight() {
        return weight;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public String getRz() {
        return rz;
    }

    public String getBrand() {
        return brand;
    }

    public String getType() {
        return type;
    }

    public static class Builder {
        private final Car car;

        public Builder() {
            car = new Car();
        }

        public Builder color(String color) {
            car.color = color;
            return this;
        }

        public Builder weight(int weight) {
            car.weight = weight;
            return this;
        }

        public Builder maxSpeed(int maxSpeed) {
            car.maxSpeed = maxSpeed;
            return this;
        }

        public Builder rz(String rz) {
            car.rz = rz;
            return this;
        }

        public Builder brand(String brand) {
            car.brand = brand;
            return this;
        }

        public Builder type(String type) {
            car.type = type;
            return this;
        }

        public Car build() {
            return car;
        }
        

    }

}
