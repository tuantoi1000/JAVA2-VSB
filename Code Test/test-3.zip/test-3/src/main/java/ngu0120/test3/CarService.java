package ngu0120.test3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


public class CarService {


    @PersistenceContext
    private EntityManager em;

    public void persist(Car car) {
        em.persist(car);
    }

    public List<Car> findAll() {
        return em.createQuery("SELECT car FROM Car AS car", Car.class).getResultList();
    }
}

