package ngu0120.test3;


import io.quarkus.runtime.Quarkus;

public class Main {

	public static void main(String[] args) {
		Quarkus.run(args);
	}

}

