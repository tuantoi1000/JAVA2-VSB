/**
 * 
 */
/**
 * @author tuantoi1000
 *
 */
module Homework4 {
	requires lombok;
	requires jakarta.persistence;
}