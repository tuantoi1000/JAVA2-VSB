package ControlInput.ControlInputInterface;

import LauchMap.PlayerMove;

public interface KeyboardInterface {
  public PlayerMove Player(final int keyCode);

}
