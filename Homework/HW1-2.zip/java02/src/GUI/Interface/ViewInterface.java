package GUI.Interface;

public interface ViewInterface {
  void displayMessage(String message);
}
