package GUI.Interface;

public interface TranslateMapInterface {

  public int getPlayerX();

  public int getPlayerY();

}
