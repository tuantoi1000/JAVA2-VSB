package GUI.Interface;

import java.awt.Graphics;

public interface ScanPanelInterface {
  public void paintComponent(Graphics g);

  public void update();
}
