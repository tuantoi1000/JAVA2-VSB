package GUI.Interface;

public interface WindowInterface {
  public PanelInterface getPanel();
}
