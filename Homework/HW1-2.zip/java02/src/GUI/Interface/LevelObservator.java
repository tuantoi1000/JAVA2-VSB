package GUI.Interface;

public interface LevelObservator {
  public void LevelSelected(int level, String name);
}
