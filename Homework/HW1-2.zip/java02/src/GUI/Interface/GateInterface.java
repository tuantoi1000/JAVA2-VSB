package GUI.Interface;

public interface GateInterface {

  public SpriteInterface[][] BrickBackgroundCoin(SpriteInterface[][] sprites,
      final int size);
}
