import React, { useState, useEffect } from "react";
import { Form, Button } from "react-bootstrap";
import axios from "axios";
import { useIntl } from 'react-intl';


const EditProductForm = ({ product, onUpdateProduct, onCancel, language },props) => {
  const [name, setName] = useState(product.name);
  const [description, setDescription] = useState(product.description);
  const [price, setPrice] = useState(product.price);
  const intl = useIntl();
  const [messages, setMessages] = useState(props);


  useEffect(() => {
    axios
      .get(`http://localhost:8080/message?language=${language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
  }, [language]);
  
  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handlePriceChange = (event) => {
    setPrice(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const updatedProduct = {
      id: product.id,
      name: name,
      description: description,
      price: price,
    };

    axios
      .put(`http://localhost:8080/products/${product.id}`, updatedProduct)
      .then((response) => {
        onUpdateProduct(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="name">
        <Form.Label>
        {messages.edit_name}

        </Form.Label>
        <Form.Control
          type="text"
          placeholder={messages.edit_product_name}
          value={name}
          onChange={handleNameChange}
        />
      </Form.Group>

      <Form.Group controlId="description">
        <Form.Label>
        {messages.product_buy}

        </Form.Label>
        <Form.Control
          type="text"
          placeholder={messages.edit_product_description}
          value={description}
          onChange={handleDescriptionChange}
        />
      </Form.Group>
      

      <Form.Group controlId="price">
        <Form.Label>
        {messages.product_buy}

        </Form.Label>
        <Form.Control
          type="number"
          placeholder={messages.edit_product_price}
          value={price}
          onChange={handlePriceChange}
        />
      </Form.Group>

      <Button variant="primary" type="submit">
      {messages.product_buy}

      </Button>

      <Button variant="secondary" onClick={onCancel}>
      {messages.product_buy}

      </Button>
    </Form>
  );
};

export default EditProductForm;
