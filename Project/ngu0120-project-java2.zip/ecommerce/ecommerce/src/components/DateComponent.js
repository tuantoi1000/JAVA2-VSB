import React, { useState, useEffect } from "react";

function DateComponent() {
  const [currentDate, setCurrentDate] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/date")
      .then((response) => response.text())
      .then((data) => setCurrentDate(data));
  }, []);

  return (
    <div>
      <h1>Current Date</h1>
      <p>{currentDate}</p>
    </div>
  );
}

export default DateComponent;
