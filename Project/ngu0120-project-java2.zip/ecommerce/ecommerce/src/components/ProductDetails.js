import React, { useState, useEffect } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function ProductDetails(props) {
  const [product, setProduct] = useState({});
  const { id } = useParams();
  const nav = useNavigate();
  const [messages, setMessages] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:8080/message?language=${props.language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
  }, [props.language]);
  useEffect(() => {
    axios
      .get(`http://localhost:8080/products/${id}`)
      .then((response) => {
        setProduct(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [id]);
  const handleBuy = (productId) => {
    const order = {
      productId: productId,
      quantity: 3,
      orderDate: new Date()
    };
  
    fetch('http://localhost:8080/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(order)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Order created:', data);
    })
    .catch(error => {
      console.error('Error creating order:', error);
    });
  }
  function addToCart(e) {
    const inputDate = new Date();
    const formattedDate = inputDate.toISOString().slice(0, 10);
    axios
      .post(`http://localhost:8080/orders`, {
        productId: id,
        quantity: 1,
        orderDate: formattedDate,
      })
      .then((response) => {
        setProduct(response.data);
        alert("order success");
        nav("/products");
      })
      .catch((error) => {
        console.log(error);
      });
  }

  return (
    <Container>
      <h1>
        {messages.product_detailsTitle}

      </h1>
      <Row>
        <Col md={6}>
          <Card>
            <Card.Img
              variant="top"
              src={
                "https://goldbelly.imgix.net/uploads/showcase_media_asset/image/79619/joes-kc-ribs-brisket-and-burnt-ends.6710e994980e485e6441b794717ad6fb.jpg?ixlib=react-9.0.2&auto=format&ar=1%3A1"
              }
            />
          </Card>
        </Col>
        <Col md={6}>
          <Card>
            <Card.Body>
              <Card.Title>{product.name}</Card.Title>
              <Card.Text>{product.description}</Card.Text>
              <Card.Text>Price: {product.price}$</Card.Text>
              <Button
                  variant="primary"
                  onClick={() => handleBuy(product.id)}
                >
                {messages.product_detailsAddToCart}

                </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default ProductDetails;
