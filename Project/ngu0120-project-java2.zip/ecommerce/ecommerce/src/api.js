import axios from "axios";
import { API_BASE_URL } from "./config";

export const getProductList = async () => {
  const response = await axios.get(`${API_BASE_URL}products`);
  return response.data;
};

export const getProductById = async (id) => {
  const response = await axios.get(`${API_BASE_URL}products/${id}`);
  return response.data;
};

export const createOrder = async (order) => {
  const response = await axios.post(`${API_BASE_URL}orders`, order);
  return response.data;
};
export const deleteProduct = async (id) => {
  const response = await axios.delete(`${API_BASE_URL}products/${id}`);
  return response.data;
};

