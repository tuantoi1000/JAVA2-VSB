import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Link, Routes, useParams } from "react-router-dom";
import { Navbar, Nav } from "react-bootstrap";
import ProductList from "./components/ProductList";
import ProductDetails from "./components/ProductDetails";
import OrderList from "./components/OrderList";
import axios from "axios";

function App() {
  const params = useParams();
  console.log(params);

  const [messages, setMessages] = useState({});
  const [language, setLanguage] = useState('en');
  const [date, setDate] = useState('');
  useEffect(() => {
    fetch('http://localhost:8080/date')
      .then(response => response.text())
      .then(date => setDate(date));
  }, []);
  useEffect(() => {
    fetchMessages();
  }, [language]);

  const fetchMessages = () => {
    axios.get(`http://localhost:8080/message?language=${language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
      
  };

  const handleChangeLanguage = (event) => {
    setLanguage(event.target.value);
  };

  return (
    <Router>
      <div>
        <Navbar bg="light" expand="lg">
          <Navbar.Brand as={Link} to="/">
            My Ecommerce App
            
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbar-nav" />
          <Navbar.Collapse id="navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link as={Link} to="/">
              {messages.navbar_home}
              </Nav.Link>
              <Nav.Link as={Link} to="/orders">
              {messages.navbar_orders }
              </Nav.Link>
              <Nav.Link as={Link} to="/products">
              {messages.navbar_products }
              </Nav.Link>
              <Nav.Link>
              {messages.today}: {date}            
              </Nav.Link>

            </Nav>
          <select value={language} onChange={handleChangeLanguage}>
            <option value="en">English</option>
            <option value="fr">French</option>
            <option value="cs">Czech</option>
          </select>
          </Navbar.Collapse>
        </Navbar>
        <Routes>
          <Route path="/products" element={<ProductList language={language} />} />
          <Route path="/products/:id" element={<ProductDetails  language={language} />} />
          <Route path="/orders" element={<OrderList language={language} />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;



