package project.java2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pj2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
